"""Stateless publication of one Agent-completed school template.

This module owns objective artifact invariants only. It does not decide what
school text means, which representative body block is correct, or whether a
section belongs in the TOC; those decisions are already embodied in the final
DOCX selected by the main Agent.
"""

from __future__ import annotations

import os
import shutil
import tempfile
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

import yaml

from docfit.fields import FieldRegistrySnapshot
from docfit.styles.capture import (
    capture_template_style_contracts,
    capture_template_style_observations,
    slot_style_contract_id,
)
from docfit.styles.profiles import DEFAULT_STYLE_PROPERTY_PROFILES
from docfit.template.materialization.vocabulary import (
    inventory_review_vocabulary_provenance_errors,
)
from docfit.template.semantic_review import review_uses_current_semantic_shape
from docfit.tools.inspection import inspect_document_snapshot
from docfit.tools.officecli import OfficeCliAdapter
from docfit.tools.package import validate_docx_package
from docfit.tools.runtime import (
    JsonObject,
    ToolFailure,
    atomic_write_json,
    read_json,
    sha256_file,
    sha256_json,
)

_PUBLICATION_OUTPUTS = {"final-template.docx", "fill-contract.yaml"}
_W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
_W = f"{{{_W_NS}}}"
_SLOT_REF_FIELD_SEPARATOR = ";field_id="
_PUBLISHED_SLOT_REQUIRED_PART_ROLES = frozenset({"fill_slot", "body_structure"})
_NO_SLOT_MATERIALIZATION_EFFECT_PART_ROLES = frozenset({"cleanup", "generated_content"})


def _style_metadata(*, field_id: str, slot_ref: str, content_type: str) -> JsonObject:
    if content_type not in {"text", "rich_text"}:
        return {"handling": "non_style"}
    style_role_id = slot_style_contract_id(slot_ref)
    style_role_type = "paragraph"
    profile = DEFAULT_STYLE_PROPERTY_PROFILES.for_role_type(style_role_type)
    return {
        "handling": "styled",
        "style_role_id": style_role_id,
        "style_role_type": style_role_type,
        "property_profile_ref": profile.ref().as_dict(),
    }


def _publication_failure(code: str, message: str) -> ToolFailure:
    return ToolFailure(
        status="error",
        origin="postcondition",
        code=code,
        message=message,
    )


def _office_validation_status(document: Path, adapter: OfficeCliAdapter) -> JsonObject:
    try:
        validation = adapter.validate_snapshot(document)
    except ToolFailure as error:
        return {
            "passed": False,
            "code": error.code,
            "origin": error.origin,
            "detail": error.message,
        }
    return {
        "passed": True,
        "code": None,
        "origin": None,
        "detail": validation.get("detail", "OfficeCLI OpenXML validation passed."),
    }


def _content_control_value(control: ET.Element, name: str) -> str | None:
    element = control.find(f"{_W}sdtPr/{_W}{name}")
    return element.get(f"{_W}val") if element is not None else None


def _parse_slot_ref(value: str) -> JsonObject | None:
    if _SLOT_REF_FIELD_SEPARATOR not in value:
        return None
    span_ref, field_id = value.rsplit(_SLOT_REF_FIELD_SEPARATOR, 1)
    if not span_ref or not field_id.strip():
        return None
    segments = span_ref.split(";")
    parsed: dict[str, str] = {}
    for segment in segments:
        if "=" not in segment:
            return None
        key, raw = segment.split("=", 1)
        if not key or not raw:
            return None
        parsed[key] = raw
    part_index = parsed.get("part_index")
    if part_index is None or not part_index.isdigit():
        return None
    scope_keys = [
        key for key in ("source_entry_id", "reading_block_id", "reading_range_id") if key in parsed
    ]
    if len(scope_keys) != 1:
        return None
    scope_key = scope_keys[0]
    return {
        "slot_ref": value,
        "span_ref": span_ref,
        "field_id": field_id.strip(),
        "part_index": int(part_index),
        "scope": {scope_key: parsed[scope_key]},
    }


def _is_legacy_docfit_slot_tag(value: str | None) -> bool:
    return isinstance(value, str) and value.startswith("slot.")


def _is_harness_slot_ref_marker(value: str | None) -> bool:
    return isinstance(value, str) and (
        value.startswith(("source_entry_id=", "reading_block_id=", "reading_range_id="))
        or _SLOT_REF_FIELD_SEPARATOR in value
    )


def _registry_has_field(registry: FieldRegistrySnapshot, field_id: str | None) -> bool:
    if not isinstance(field_id, str) or not field_id.strip():
        return False
    try:
        registry.lookup(field_id.strip())
    except ToolFailure:
        return False
    return True


def _slot_protocol_entry(
    *,
    field_id: str,
    slot_ref: str,
) -> JsonObject | None:
    parsed = _parse_slot_ref(slot_ref)
    if parsed is None or parsed.get("field_id") != field_id:
        return None
    return parsed


def publication_slot_protocol_status(
    *,
    candidate_docx: Path,
    registry: FieldRegistrySnapshot,
    allow_no_slots: bool = False,
) -> JsonObject:
    """Check only the DocFit-owned slot marker protocol needed for publication."""

    try:
        with zipfile.ZipFile(candidate_docx) as archive:
            document = ET.fromstring(archive.read("word/document.xml"))
    except (OSError, KeyError, zipfile.BadZipFile, ET.ParseError) as error:
        return {
            "status": "needs_input",
            "failure": {
                "code": "source_candidate_not_publishable",
                "message": "The source candidate cannot be inspected for DocFit slots.",
                "retryable": False,
                "suggested_actions": [
                    "Use a valid DOCX candidate returned by docfit_apply.",
                ],
            },
            "error": str(error),
        }

    controls = list(document.iter(f"{_W}sdt"))
    slots: list[JsonObject] = []
    invalid: list[JsonObject] = []
    seen_tags: set[str] = set()
    for control in controls:
        field_id = _content_control_value(control, "alias")
        slot_ref = _content_control_value(control, "tag")
        if _is_legacy_docfit_slot_tag(slot_ref):
            invalid.append({"code": "legacy_slot_ref_marker", "slot_ref": slot_ref})
            continue
        registered_alias = _registry_has_field(registry, field_id)
        harness_marker = _is_harness_slot_ref_marker(slot_ref)
        if not registered_alias and not harness_marker:
            continue
        if registered_alias and not isinstance(slot_ref, str):
            invalid.append(
                {
                    "code": "content_control_slot_ref_missing",
                    "field_id": field_id,
                    "message": (
                        "A Registry-bound content control is missing its Harness slot_ref tag."
                    ),
                }
            )
            continue
        if harness_marker and not isinstance(field_id, str):
            invalid.append(
                {
                    "code": "content_control_identity_missing",
                    "slot_ref": slot_ref,
                    "message": (
                        "A Harness slot_ref content control is missing its Registry alias."
                    ),
                }
            )
            continue
        if not isinstance(slot_ref, str) or not isinstance(field_id, str):
            continue
        protocol = _slot_protocol_entry(field_id=field_id, slot_ref=slot_ref)
        if protocol is None:
            invalid.append(
                {
                    "code": "content_control_identity_missing",
                    "slot_ref": slot_ref,
                    "field_id": field_id,
                    "message": (
                        "Every DocFit slot control must expose a Registry alias and "
                        "matching Harness slot_ref tag."
                    ),
                }
            )
            continue
        if slot_ref in seen_tags:
            invalid.append({"code": "content_control_tag_duplicate", "slot_ref": slot_ref})
            continue
        seen_tags.add(slot_ref)
        try:
            field = registry.lookup(field_id)
        except ToolFailure as error:
            invalid.append(
                {
                    "code": "content_control_field_invalid",
                    "slot_ref": slot_ref,
                    "field_id": field_id,
                    "message": error.message,
                }
            )
            continue
        if str(field.get("content_type", "")).casefold() == "section":
            invalid.append(
                {
                    "code": "body_structure_container_field_published",
                    "slot_ref": slot_ref,
                    "field_id": field_id,
                    "message": (
                        "Body-structure container fields are not published slot controls."
                    ),
                }
            )
            continue
        slots.append(
            {
                "slot_ref": slot_ref,
                "span_ref": protocol["span_ref"],
                "field_id": field_id,
            }
        )
    if invalid:
        return {
            "status": "needs_input",
            "slot_count": len(slots),
            "school_content_control_count": len(controls) - len(slots),
            "invalid_slots": invalid,
            "failure": {
                "code": "source_candidate_slot_protocol_invalid",
                "message": "One or more DocFit slot controls are not publication-compatible.",
                "retryable": False,
                "suggested_actions": [
                    (
                        "Repair the selected slot identity with a reviewed "
                        "materialize_slot action package."
                    ),
                ],
            },
        }
    if not slots and allow_no_slots:
        return {
            "status": "ok",
            "slot_count": 0,
            "school_content_control_count": len(controls),
            "slots": [],
            "failure": None,
        }
    if not slots:
        return {
            "status": "needs_input",
            "slot_count": 0,
            "school_content_control_count": len(controls),
            "failure": {
                "code": "source_candidate_not_publishable",
                "message": (
                    "The source may contain school fill controls, but it has no DocFit-owned "
                    "Harness slot_ref content-control markers."
                ),
                "retryable": False,
                "suggested_actions": [
                    "Materialize accepted Harness resolved_spans before publication.",
                    "Return needs_input if the current write backend cannot create a DocFit slot.",
                ],
            },
        }
    return {
        "status": "ok",
        "slot_count": len(slots),
        "school_content_control_count": len(controls) - len(slots),
        "slots": slots,
        "failure": None,
    }


def _atomic_write_yaml(path: Path, value: JsonObject) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=path.parent
    )
    os.close(descriptor)
    temporary = Path(temporary_name)
    try:
        temporary.write_text(
            yaml.safe_dump(value, allow_unicode=True, sort_keys=False, width=1000),
            encoding="utf-8",
            newline="\n",
        )
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def _assert_output_directory_ready(output: Path, output_contract: Path) -> None:
    output_dir = output.parent
    if not output_dir.exists():
        return
    entries = sorted(path.name for path in output_dir.iterdir())
    if not entries:
        return
    if output.name in entries or output_contract.name in entries:
        raise ToolFailure(
            status="needs_input",
            origin="request",
            code="template_publication_exists",
            message="Publication never overwrites an existing Word/Fill Contract pair.",
        )
    raise ToolFailure(
        status="needs_input",
        origin="request",
        code="template_output_directory_not_clean",
        message="The template output directory must be empty before publication.",
    )


def _published_slots(
    *,
    candidate_docx: Path,
    registry: FieldRegistrySnapshot,
    office: OfficeCliAdapter,
) -> tuple[list[JsonObject], int]:
    inspection = inspect_document_snapshot(
        candidate_docx,
        office,
        selector="paragraph, table, picture, run, sdt, shape",
    )
    controls = [item for item in inspection.objects if item.kind == "sdt"]
    slots: list[JsonObject] = []
    structure_count = 0
    seen_tags: set[str] = set()
    for control in controls:
        field_id = control.format.get("alias")
        slot_ref = control.format.get("tag")
        # School-authored controls are legitimate source content.  DocFit owns
        # only controls carrying a Harness slot_ref marker; applying Registry
        # rules to every pre-existing SDT would silently redefine school
        # semantics at publication time.  Once a control uses a Registry alias,
        # it is no longer safe to treat it as school-authored: publication must
        # prove it came from accepted Harness spans.
        if _is_legacy_docfit_slot_tag(slot_ref):
            raise _publication_failure(
                "legacy_slot_ref_marker",
                "Publication rejects legacy slot.* content-control tags.",
            )
        registered_alias = _registry_has_field(registry, field_id)
        harness_marker = _is_harness_slot_ref_marker(slot_ref)
        if not registered_alias and not harness_marker:
            continue
        if registered_alias and not isinstance(slot_ref, str):
            raise _publication_failure(
                "content_control_slot_ref_missing",
                "A Registry-bound content control is missing its Harness slot_ref tag.",
            )
        if harness_marker and not isinstance(field_id, str):
            raise _publication_failure(
                "content_control_identity_missing",
                "A Harness slot_ref content control is missing its Registry alias.",
            )
        if not isinstance(slot_ref, str) or not isinstance(field_id, str):
            continue
        protocol = _slot_protocol_entry(field_id=field_id, slot_ref=slot_ref)
        if protocol is None:
            raise _publication_failure(
                "content_control_identity_missing",
                "Every DocFit slot control must expose a Registry alias and Harness slot_ref tag.",
            )
        try:
            field = registry.lookup(field_id)
        except ToolFailure as error:
            raise _publication_failure(
                "content_control_field_invalid",
                "A DocFit slot control references a field outside the Registry snapshot.",
            ) from error
        if str(field.get("content_type", "")).casefold() == "section":
            raise _publication_failure(
                "body_structure_container_field_published",
                (
                    "Body-structure container fields are internal structure refs, not "
                    "published slot controls."
                ),
            )
        if slot_ref in seen_tags:
            raise _publication_failure(
                "content_control_tag_duplicate",
                "Final content-control tags must be unique within the Word document.",
            )
        seen_tags.add(slot_ref)
        content_type = str(field.get("content_type", "text"))
        slot: JsonObject = {
            "slot_ref": slot_ref,
            "span_ref": protocol["span_ref"],
            "field_id": field_id,
            "content_type": content_type,
            "required": True,
            "locator": {
                "type": "content_control_tag",
                "value": slot_ref,
                "story": "document",
                "part": "word/document.xml",
                "expected_match_count": 1,
            },
        }
        slot.update(
            _style_metadata(
                field_id=field_id,
                slot_ref=slot_ref,
                content_type=content_type,
            )
        )
        label = field.get("label")
        if isinstance(label, str) and label:
            slot["label"] = label
        slots.append(slot)
    if structure_count > 1:
        raise _publication_failure(
            "body_structure_duplicate",
            "The final template may contain at most one reusable body structure.",
        )
    return slots, structure_count


def _accepted_slot_provenance(
    root: Path,
    registry: FieldRegistrySnapshot,
    *,
    source_hash: str,
) -> dict[str, JsonObject]:
    inventory_path = root / "work/.docfit/harness/object-inventory.json"
    review_path = root / "work/.docfit/harness/semantic-judgments.json"
    materialization_path = root / "work/.docfit/post-unit-materialization/materialization.json"
    if (
        not inventory_path.is_file()
        or not review_path.is_file()
        or not materialization_path.is_file()
    ):
        raise _publication_failure(
            "template_slot_provenance_missing",
            (
                "Publication requires accepted inventory, semantic judgments, and "
                "materialization receipt evidence."
            ),
        )
    inventory = read_json(inventory_path)
    review = read_json(review_path)
    materialization = read_json(materialization_path)
    if not _review_document_hash_matches(review, inventory, source_hash):
        raise _publication_failure(
            "template_slot_source_mismatch",
            "Slot publication semantic provenance is not bound to the source template.",
        )
    if not _review_semantic_digest_matches(review):
        raise _publication_failure(
            "template_slot_semantic_digest_mismatch",
            "Slot publication requires a current semantic_judgments digest.",
        )
    vocabulary_errors = inventory_review_vocabulary_provenance_errors(
        inventory=inventory,
        review=review,
        registry=registry,
    )
    if vocabulary_errors:
        _raise_publication_vocabulary_failure(vocabulary_errors[0])
    if not review_uses_current_semantic_shape(
        inventory=inventory,
        review=review,
        expected_vocabulary=registry.pre_input_vocabulary(),
    ):
        raise _publication_failure(
            "template_slot_semantics_invalid",
            (
                "Slot publication requires current scope, ordered parts, and complete "
                "Harness resolved span coverage."
            ),
        )
    _assert_materialization_bound_to_review(
        materialization=materialization,
        review=review,
        registry=registry,
    )
    vocabulary = review.get("field_id_vocabulary")
    if not isinstance(vocabulary, dict):
        raise _publication_failure(
            "field_vocabulary_provenance_missing",
            "Accepted semantic judgments must include the pre-input field vocabulary.",
        )
    raw_allowed = vocabulary["allowed_field_ids"]
    if not isinstance(raw_allowed, list):
        raise _publication_failure(
            "field_vocabulary_provenance_missing",
            "Accepted semantic judgments must include allowed_field_ids.",
        )
    allowed_field_ids = {item for item in raw_allowed if isinstance(item, str)}
    materialized_operations = _materialized_slot_operations(materialization)
    result: dict[str, JsonObject] = {}
    raw_judgments = review.get("semantic_judgments")
    if not isinstance(raw_judgments, list):
        return result
    for judgment_index, judgment in enumerate(raw_judgments):
        if not isinstance(judgment, dict):
            continue
        parts = judgment.get("parts")
        spans = judgment.get("resolved_spans")
        if not isinstance(parts, list) or not isinstance(spans, list):
            continue
        for span in spans:
            if not isinstance(span, dict):
                continue
            slot_ref = span.get("slot_ref")
            field_id = span.get("field_id")
            span_ref = span.get("span_ref")
            part_index = span.get("part_index")
            if (
                not isinstance(slot_ref, str)
                or not isinstance(field_id, str)
                or not isinstance(span_ref, str)
                or not isinstance(part_index, int)
                or isinstance(part_index, bool)
            ):
                continue
            if field_id not in allowed_field_ids:
                raise _publication_failure(
                    "published_slot_field_not_in_vocabulary",
                    "A published slot field_id is not in the accepted input vocabulary.",
                )
            if field_id != registry.lookup(field_id).get("field_id"):
                raise _publication_failure(
                    "published_slot_field_invalid",
                    "A published slot field_id is not present in the Registry snapshot.",
                )
            if not _materialized_operation_matches(
                materialized_operations,
                slot_ref=slot_ref,
                span_ref=span_ref,
                field_id=field_id,
            ):
                raise _publication_failure(
                    "published_slot_operation_mismatch",
                    (
                        "A published slot_ref is missing a matching materialization "
                        "operation for the accepted field_id and span_ref."
                    ),
                )
            if not _materialized_receipt_matches(
                materialization,
                slot_ref=slot_ref,
                span_ref=span_ref,
                field_id=field_id,
            ):
                raise _publication_failure(
                    "published_slot_receipt_missing",
                    (
                        "A published slot_ref is missing matching field_id/span_ref "
                        "evidence in the materialization receipt."
                    ),
                )
            part = parts[part_index] if 0 <= part_index < len(parts) else None
            if not isinstance(part, dict) or part.get("field_id") != field_id:
                raise _publication_failure(
                    "published_slot_part_mismatch",
                    "A published slot_ref does not match its accepted ordered part.",
                )
            parsed = _parse_slot_ref(slot_ref)
            if (
                parsed is None
                or parsed.get("span_ref") != span_ref
                or parsed.get("field_id") != field_id
            ):
                raise _publication_failure(
                    "published_slot_ref_invalid",
                    "A published slot_ref does not match its Harness span_ref and field_id.",
                )
            provenance: JsonObject = {
                "source": "harness_resolved_span",
                "source_judgment_ref": f"semantic_judgments[{judgment_index}]",
                "part_index": part_index,
                "span_ref": span_ref,
                "slot_ref": slot_ref,
                "field_vocabulary_digest": vocabulary.get("digest"),
            }
            reading_block_id = span.get("reading_block_id")
            if isinstance(reading_block_id, str) and reading_block_id.strip():
                provenance["reading_block_id"] = reading_block_id.strip()
            result[slot_ref] = provenance
    return result


def _review_document_hash_matches(
    review: JsonObject,
    inventory: JsonObject,
    source_hash: str,
) -> bool:
    return (
        review.get("document_sha256") == source_hash
        and inventory.get("document_sha256") == source_hash
    )


def _review_semantic_digest_matches(review: JsonObject) -> bool:
    raw_judgments = review.get("semantic_judgments")
    digest = review.get("semantic_judgments_sha256")
    return (
        isinstance(raw_judgments, list)
        and isinstance(digest, str)
        and sha256_json(raw_judgments) == digest
    )


def _review_part_roles(review: JsonObject) -> tuple[str, ...] | None:
    raw_judgments = review.get("semantic_judgments")
    if not isinstance(raw_judgments, list) or not raw_judgments:
        return None
    roles: list[str] = []
    for judgment in raw_judgments:
        if not isinstance(judgment, dict):
            return None
        parts = judgment.get("parts")
        if not isinstance(parts, list) or not parts:
            return None
        for part in parts:
            if not isinstance(part, dict):
                return None
            role = part.get("role")
            if not isinstance(role, str) or not role.strip():
                return None
            roles.append(role.strip().casefold())
    return tuple(roles)


def _review_field_ids(review: JsonObject) -> tuple[str, ...]:
    raw_judgments = review.get("semantic_judgments")
    if not isinstance(raw_judgments, list):
        return ()
    field_ids: list[str] = []
    for judgment in raw_judgments:
        if not isinstance(judgment, dict):
            continue
        for key in ("parts", "resolved_spans"):
            values = judgment.get(key)
            if not isinstance(values, list):
                continue
            for item in values:
                if not isinstance(item, dict):
                    continue
                field_id = item.get("field_id")
                if isinstance(field_id, str) and field_id.strip():
                    field_ids.append(field_id.strip())
    return tuple(dict.fromkeys(field_ids))


def _accepted_no_slot_publication_provenance(
    *,
    root: Path,
    registry: FieldRegistrySnapshot,
    source_hash: str,
    candidate_is_source: bool,
) -> JsonObject:
    inventory_path = root / "work/.docfit/harness/object-inventory.json"
    review_path = root / "work/.docfit/harness/semantic-judgments.json"
    if not inventory_path.is_file() or not review_path.is_file():
        raise _publication_failure(
            "template_no_slot_provenance_missing",
            "No-slot publication requires accepted Harness semantic provenance.",
        )
    inventory = read_json(inventory_path)
    review = read_json(review_path)
    if not _review_document_hash_matches(review, inventory, source_hash):
        raise _publication_failure(
            "template_no_slot_source_mismatch",
            "No-slot publication semantic provenance is not bound to the source template.",
        )
    if not _review_semantic_digest_matches(review):
        raise _publication_failure(
            "template_no_slot_semantic_digest_mismatch",
            "No-slot publication requires a current semantic_judgments digest.",
        )
    vocabulary_errors = inventory_review_vocabulary_provenance_errors(
        inventory=inventory,
        review=review,
        registry=registry,
    )
    if vocabulary_errors:
        _raise_publication_vocabulary_failure(vocabulary_errors[0])
    if not review_uses_current_semantic_shape(
        inventory=inventory,
        review=review,
        expected_vocabulary=registry.pre_input_vocabulary(),
    ):
        raise _publication_failure(
            "template_no_slot_semantics_invalid",
            (
                "No-slot publication requires current scope, ordered parts, and "
                "complete Harness resolved span coverage."
            ),
        )
    vocabulary = review.get("field_id_vocabulary")
    raw_allowed = vocabulary.get("allowed_field_ids") if isinstance(vocabulary, dict) else None
    allowed_field_ids = {item for item in raw_allowed or [] if isinstance(item, str)}
    for field_id in _review_field_ids(review):
        if field_id not in allowed_field_ids:
            raise _publication_failure(
                "template_no_slot_field_not_in_vocabulary",
                "No-slot semantic field_id values must come from the accepted vocabulary.",
            )
        try:
            registry.lookup(field_id)
        except ToolFailure as error:
            raise _publication_failure(
                "template_no_slot_field_invalid",
                "No-slot semantic field_id values must exist in the Registry snapshot.",
            ) from error
    roles = _review_part_roles(review)
    if roles is None:
        raise _publication_failure(
            "template_no_slot_semantics_invalid",
            "No-slot publication requires current scope plus ordered parts semantics.",
        )
    if any(role in _PUBLISHED_SLOT_REQUIRED_PART_ROLES for role in roles):
        raise _publication_failure(
            "published_slots_missing_for_executable_semantics",
            "Accepted fill_slot or body_structure semantics require published slots.",
        )
    materialization_path = root / "work/.docfit/post-unit-materialization/materialization.json"
    if not candidate_is_source:
        if not materialization_path.is_file():
            raise _publication_failure(
                "template_no_slot_materialization_missing",
                "No-slot materialized candidates require materialization receipt evidence.",
            )
        materialization = read_json(materialization_path)
        _assert_materialization_bound_to_review(
            materialization=materialization,
            review=review,
            registry=registry,
        )
    elif any(role in _NO_SLOT_MATERIALIZATION_EFFECT_PART_ROLES for role in roles):
        raise _publication_failure(
            "template_no_slot_materialization_missing",
            "Cleanup or generated-content no-slot semantics require a materialized candidate.",
        )
    provenance: JsonObject = {
        "source": "accepted_no_slot_semantic_review",
        "semantic_judgments_sha256": review.get("semantic_judgments_sha256"),
        "field_vocabulary_digest": review.get("field_vocabulary_digest"),
        "judgment_count": len(review["semantic_judgments"]),
        "roles": list(dict.fromkeys(roles)),
    }
    if not candidate_is_source:
        provenance["materialization_receipt"] = str(materialization_path.relative_to(root))
    return provenance


def _raise_publication_vocabulary_failure(error: JsonObject) -> None:
    code = error.get("code")
    message = error.get("message")
    raise _publication_failure(
        str(code) if isinstance(code, str) and code.strip() else "field_vocabulary_invalid",
        str(message)
        if isinstance(message, str) and message.strip()
        else "Publication requires accepted pre-input field vocabulary provenance.",
    )


def _assert_materialization_bound_to_review(
    *,
    materialization: JsonObject,
    review: JsonObject,
    registry: FieldRegistrySnapshot,
) -> None:
    if materialization.get("status") != "ok":
        raise _publication_failure(
            "published_slot_materialization_not_ok",
            "Publication requires an ok materialization receipt.",
        )
    review_digest = review.get("semantic_judgments_sha256")
    if (
        not isinstance(review_digest, str)
        or materialization.get("semantic_judgments_sha256") != review_digest
    ):
        raise _publication_failure(
            "published_slot_materialization_review_mismatch",
            "Materialization receipt is not bound to the accepted semantic judgments.",
        )
    vocabulary_digest = review.get("field_vocabulary_digest")
    if (
        not isinstance(vocabulary_digest, str)
        or materialization.get("field_vocabulary_digest") != vocabulary_digest
    ):
        raise _publication_failure(
            "published_slot_materialization_vocabulary_mismatch",
            "Materialization receipt is not bound to the accepted field vocabulary.",
        )
    if materialization.get("field_registry_ref") != registry.identity():
        raise _publication_failure(
            "published_slot_materialization_registry_mismatch",
            "Materialization receipt is not bound to the current Registry snapshot.",
        )


def _materialized_slot_operations(materialization: JsonObject) -> dict[str, list[JsonObject]]:
    slots: dict[str, list[JsonObject]] = {}
    operations = materialization.get("operations")
    if isinstance(operations, list):
        for operation in operations:
            for item in _slot_infos_from_mapping(operation):
                slot_ref = item.get("slot_ref")
                if isinstance(slot_ref, str) and slot_ref.strip():
                    slots.setdefault(slot_ref.strip(), []).append(item)
    return slots


def _materialized_operation_matches(
    materialized_operations: dict[str, list[JsonObject]],
    *,
    slot_ref: str,
    span_ref: str,
    field_id: str,
) -> bool:
    return any(
        item.get("span_ref") == span_ref and item.get("field_id") == field_id
        for item in materialized_operations.get(slot_ref, [])
    )


def _materialized_receipt_matches(
    materialization: JsonObject,
    *,
    slot_ref: str,
    span_ref: str,
    field_id: str,
) -> bool:
    receipts = materialization.get("mutation_receipts")
    if isinstance(receipts, list):
        for receipt in receipts:
            if not isinstance(receipt, dict):
                continue
            slot_refs = _strings(receipt.get("slot_refs")) + _ref_values_from_mapping(
                receipt.get("operation"),
                "slot_ref",
            )
            if slot_ref not in slot_refs:
                continue
            field_ids = _strings(receipt.get("field_ids")) + _field_ids_from_mapping(
                receipt.get("operation")
            )
            span_refs = _strings(receipt.get("span_refs")) + _ref_values_from_mapping(
                receipt.get("operation"),
                "span_ref",
            )
            if field_id in field_ids and span_ref in span_refs:
                return True
    return False


def _slot_infos_from_mapping(value: object) -> list[JsonObject]:
    if not isinstance(value, dict):
        return []
    result: list[JsonObject] = []
    info = _slot_info_from_mapping(value)
    if info is not None:
        result.append(info)
    members = value.get("members")
    if isinstance(members, list):
        for member in members:
            member_info = _slot_info_from_mapping(member)
            if member_info is not None:
                result.append(member_info)
    return result


def _slot_info_from_mapping(value: object) -> JsonObject | None:
    if not isinstance(value, dict):
        return None
    slot_ref = value.get("slot_ref")
    if not isinstance(slot_ref, str) or not slot_ref.strip():
        return None
    parsed = _parse_slot_ref(slot_ref.strip())
    if parsed is None:
        return None
    field_id = value.get("field_id")
    field_id = field_id.strip() if isinstance(field_id, str) and field_id.strip() else None
    span_ref = value.get("span_ref")
    span_ref = span_ref.strip() if isinstance(span_ref, str) and span_ref.strip() else None
    if field_id is None or span_ref is None:
        return None
    return {
        "slot_ref": slot_ref.strip(),
        "span_ref": span_ref,
        "field_id": field_id,
    }


def _field_ids_from_mapping(value: object) -> list[str]:
    if not isinstance(value, dict):
        return []
    values: list[str] = []
    field_id = value.get("field_id")
    if isinstance(field_id, str) and field_id.strip():
        values.append(field_id.strip())
    members = value.get("members")
    if isinstance(members, list):
        for member in members:
            if not isinstance(member, dict):
                continue
            member_field_id = member.get("field_id")
            if isinstance(member_field_id, str) and member_field_id.strip():
                values.append(member_field_id.strip())
    return list(dict.fromkeys(values))


def _ref_values_from_mapping(value: object, key: str) -> list[str]:
    if not isinstance(value, dict):
        return []
    values: list[str] = []
    item = value.get(key)
    if isinstance(item, str) and item.strip():
        values.append(item.strip())
    plural = value.get(f"{key}s")
    if isinstance(plural, list):
        values.extend(
            item.strip() for item in plural if isinstance(item, str) and item.strip()
        )
    members = value.get("members")
    if isinstance(members, list):
        for member in members:
            if not isinstance(member, dict):
                continue
            member_value = member.get(key)
            if isinstance(member_value, str) and member_value.strip():
                values.append(member_value.strip())
    return list(dict.fromkeys(values))


def _strings(value: object) -> list[str]:
    if not isinstance(value, list):
        return []
    return list(
        dict.fromkeys(item.strip() for item in value if isinstance(item, str) and item.strip())
    )


def _attach_slot_provenance(
    *,
    slots: list[JsonObject],
    provenance_by_slot_ref: dict[str, JsonObject],
) -> None:
    for slot in slots:
        slot_ref = slot.get("slot_ref")
        if not isinstance(slot_ref, str):
            raise _publication_failure(
                "published_slot_ref_missing",
                "Every fill-contract slot must carry its Harness slot_ref.",
            )
        provenance = provenance_by_slot_ref.get(slot_ref)
        if provenance is None:
            raise _publication_failure(
                "published_slot_provenance_missing",
                "A fill-contract slot is not backed by an accepted ordered part.",
            )
        slot["provenance"] = provenance


def publish_template_artifact(
    *,
    task_root: Path,
    source_docx: Path,
    candidate_docx: Path,
    field_registry: Path,
    validation: JsonObject,
    visual_review: JsonObject,
    allow_no_slots: bool = False,
    office: OfficeCliAdapter | None = None,
) -> JsonObject:
    """Bind final Word, Fill Contract, style evidence, and review to one hash."""

    adapter = office or OfficeCliAdapter()
    root = task_root.expanduser().resolve(strict=True)
    source = source_docx.expanduser().resolve(strict=True)
    candidate = candidate_docx.expanduser().resolve(strict=True)
    registry = FieldRegistrySnapshot.load(field_registry)
    source_hash = sha256_file(source)
    candidate_hash = sha256_file(candidate)
    output = root / "output/final-template.docx"
    output_contract = root / "output/fill-contract.yaml"
    _assert_output_directory_ready(output, output_contract)
    if validation.get("final_sha256") != candidate_hash:
        raise _publication_failure(
            "validation_snapshot_mismatch",
            "Independent validation is not bound to the Harness-selected final Word.",
        )
    if visual_review.get("document_sha256") != candidate_hash:
        raise _publication_failure(
            "visual_review_snapshot_mismatch",
            "Final visual-review evidence is not bound to the Harness-selected Word.",
        )
    validate_docx_package(candidate)
    source_office_validation = _office_validation_status(source, adapter)
    candidate_office_validation = _office_validation_status(candidate, adapter)
    if (
        source_office_validation["passed"] is True
        and candidate_office_validation["passed"] is not True
    ):
        raise _publication_failure(
            "template_publication_officecli_regression",
            "The final template introduced an OfficeCLI OpenXML regression.",
        )
    office_validation = (
        candidate_office_validation
        if candidate_office_validation["passed"] is True
        else {
            "passed": False,
            "source": source_office_validation,
            "final": candidate_office_validation,
            "new_officecli_regression": "UNKNOWN",
        }
    )
    slots, structure_count = _published_slots(
        candidate_docx=candidate,
        registry=registry,
        office=adapter,
    )
    no_slot_provenance: JsonObject | None = None
    if slots:
        _attach_slot_provenance(
            slots=slots,
            provenance_by_slot_ref=_accepted_slot_provenance(
                root,
                registry,
                source_hash=source_hash,
            ),
        )
    elif allow_no_slots:
        no_slot_provenance = _accepted_no_slot_publication_provenance(
            root=root,
            registry=registry,
            source_hash=source_hash,
            candidate_is_source=candidate == source,
        )
    else:
        raise _publication_failure(
            "fillable_slots_missing",
            "A clean school template must expose at least one Registry-bound fill interface.",
        )

    if slots:
        style_contracts, style_capture = capture_template_style_contracts(candidate, slots)
        school_capture = capture_template_style_observations(candidate, slots)
        if school_capture.failed_observations:
            raise _publication_failure(
                "school_style_observation_failed",
                "One or more final fill interfaces have no evaluable school style evidence.",
            )
        refs = {
            style.style_contract_id: {
                "style_contract_id": style.style_contract_id,
                "contract_digest": style.contract_digest,
            }
            for style in style_contracts.styles
        }
        for slot in slots:
            slot["style_contract_ref"] = refs[
                slot_style_contract_id(str(slot["slot_ref"]))
            ]
        style_payload = [style.as_dict() for style in style_contracts.styles]
        style_contract_set_digest = style_contracts.digest
        profile_registry_digest = school_capture.observation_set.profile_registry_digest
        school_observation_set_digest = school_capture.school_observation_set_digest
        school_candidates = list(school_capture.school_candidates)
        known_gaps = list(school_capture.known_gaps)
        school_capture_status = school_capture.status
        school_capture_payload = school_capture.as_dict()
    else:
        style_capture = {
            "status": "skipped",
            "reason": "accepted_terminal_source_noop_without_registry_slots",
        }
        style_payload = []
        style_contract_set_digest = sha256_json(
            {"schema_version": "docfit-template-style-contract-set/v1", "styles": []}
        )
        profile_registry_digest = DEFAULT_STYLE_PROPERTY_PROFILES.registry_digest
        school_observation_set_digest = sha256_json(
            {
                "schema_version": "docfit-school-style-observations/v1",
                "school_candidates": [],
                "known_gaps": [],
            }
        )
        school_candidates = []
        known_gaps = []
        school_capture_status = "skipped_no_registry_slots"
        school_capture_payload = {
            "status": school_capture_status,
            "profile_registry_digest": profile_registry_digest,
            "school_observation_set_digest": school_observation_set_digest,
            "school_candidates": [],
            "known_gaps": [],
            "failed_observations": [],
        }

    publication_dir = root / "work/.docfit/template-publication"
    publication_dir.mkdir(parents=True, exist_ok=True)
    atomic_write_json(publication_dir / "school-style-observations.json", school_capture_payload)
    contract_provenance: JsonObject = {
        "source_sha256": source_hash,
        "body_structure_count": structure_count,
        "agent_owned_semantics": True,
    }
    if no_slot_provenance is not None:
        contract_provenance["no_slot_semantic_provenance"] = no_slot_provenance

    fill_contract: JsonObject = {
        "schema_version": "docfit-template-fill-contract/v2",
        "contract_id": f"docfit.template.{candidate_hash[:16]}",
        "artifact_role": "template_fill_contract",
        "status": "candidate_pending_human_acceptance",
        "revision": "1",
        "template_sha256": candidate_hash,
        "field_registry_ref": registry.identity(),
        "marker_protocol": "docfit-content-control-marker/v1",
        "profile_registry_digest": profile_registry_digest,
        "school_observation_set_digest": school_observation_set_digest,
        "school_style_candidates": school_candidates,
        "known_school_style_gaps": known_gaps,
        "regions": [],
        "slots": slots,
        "styles": style_payload,
        "style_contract_set_digest": style_contract_set_digest,
        "provenance": contract_provenance,
        "review": {
            "status": "machine_checked_pending_human_signoff",
            "reviewer": None,
            "reviewed_at": None,
            "conclusion": "pending",
            "blockers": [],
            "prepared_by": "docfit-main-agent",
        },
        "validation": {
            "docx_validate": validation,
            "final_visual_review": visual_review,
            "style_capture": style_capture,
            "school_style_observation": {
                "status": school_capture_status,
                "artifact_path": "school-style-observations.json",
            },
            "officecli_validation": office_validation,
        },
    }
    contract_path = publication_dir / "fill-contract.yaml"
    _atomic_write_yaml(contract_path, fill_contract)

    if output.exists() or output_contract.exists():
        raise ToolFailure(
            status="needs_input",
            origin="request",
            code="template_publication_exists",
            message="Publication never overwrites an existing Word/Fill Contract pair.",
        )
    output.parent.mkdir(parents=True, exist_ok=True)
    word_descriptor, word_temporary_name = tempfile.mkstemp(
        prefix=".final-template-", suffix=".docx", dir=output.parent
    )
    os.close(word_descriptor)
    contract_descriptor, contract_temporary_name = tempfile.mkstemp(
        prefix=".fill-contract-", suffix=".yaml", dir=output.parent
    )
    os.close(contract_descriptor)
    word_temporary = Path(word_temporary_name)
    contract_temporary = Path(contract_temporary_name)
    try:
        shutil.copyfile(candidate, word_temporary)
        shutil.copyfile(contract_path, contract_temporary)
        word_temporary.chmod(0o600)
        contract_temporary.chmod(0o600)
        os.link(word_temporary, output)
        try:
            os.link(contract_temporary, output_contract)
        except BaseException:
            output.unlink(missing_ok=True)
            raise
    except FileExistsError as error:
        raise ToolFailure(
            status="needs_input",
            origin="request",
            code="template_publication_exists",
            message="Publication never overwrites an existing Word/Fill Contract pair.",
        ) from error
    finally:
        word_temporary.unlink(missing_ok=True)
        contract_temporary.unlink(missing_ok=True)
    published_entries = sorted(path.name for path in output.parent.iterdir())
    if set(published_entries) != _PUBLICATION_OUTPUTS:
        output.unlink(missing_ok=True)
        output_contract.unlink(missing_ok=True)
        raise _publication_failure(
            "template_output_directory_not_clean",
            "Publication must leave exactly final-template.docx and fill-contract.yaml.",
        )
    if (
        sha256_file(output) != candidate_hash
        or sha256_file(output_contract) != sha256_file(contract_path)
    ):
        output.unlink(missing_ok=True)
        output_contract.unlink(missing_ok=True)
        raise _publication_failure(
            "published_artifact_hash_mismatch",
            "The published Word/Fill Contract pair differs from the validated artifacts.",
        )

    counts: JsonObject = {
        "slot": len(slots),
        "remove": 0,
        "manual": 1 if allow_no_slots and not slots else 0,
        "gap": len(known_gaps),
        "unresolved": sum(
            len(item.get("unresolved_properties", []))
            for item in known_gaps
            if isinstance(item, dict)
        ),
    }
    receipt: JsonObject = {
        "schema_version": 1,
        "status": "ok",
        "published": True,
        "artifact_path": "output/final-template.docx",
        "fill_contract_path": "output/fill-contract.yaml",
        "template_sha256": candidate_hash,
        "counts": counts,
        "checks": [
            {"name": "source_unchanged", "result": "ok", "sha256": source_hash},
            {"name": "registry_bound", "result": "ok", **registry.identity()},
            {"name": "validation_bound", "result": "ok"},
            {"name": "visual_review_bound", "result": "ok"},
            {"name": "package_reopens", "result": "ok"},
            {"name": "fill_contract_hash_matches_word", "result": "ok"},
        ],
    }
    atomic_write_json(publication_dir / "build-report.json", receipt)
    return receipt
