"""Typed materialization handlers."""
