"""Snapshot inspection and opaque object-ref generation."""

from __future__ import annotations

import re
import shutil
import tempfile
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from xml.etree import ElementTree as ET

from docfit.tools.officecli import OfficeCliAdapter
from docfit.tools.package import validate_docx_package
from docfit.tools.runtime import JsonObject, ToolFailure, sha256_file, sha256_json

W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
A_NS = "http://schemas.openxmlformats.org/drawingml/2006/main"
V_NS = "urn:schemas-microsoft-com:vml"

_FORMAT_ALIASES = {
    "align": "alignment",
    "keepLines": "keepTogether",
    "keepNext": "keepWithNext",
}
_PUBLIC_FORMAT_KEYS = {
    "alias",
    "alignment",
    "bold",
    "color",
    "editable",
    "font",
    "font.ascii",
    "font.eastAsia",
    "font.hAnsi",
    "font.ea",
    "font.latin",
    "height",
    "id",
    "italic",
    "keepTogether",
    "keepWithNext",
    "lineRule",
    "lineSpacing",
    "pageBreakBefore",
    "size",
    "spaceAfter",
    "spaceBefore",
    "tag",
    "type",
    "widowControl",
    "width",
}
@dataclass(frozen=True, slots=True)
class InspectedObject:
    locator: str
    kind: str
    text: str
    style: str | None
    format: JsonObject
    object_ref: JsonObject
    resolved_style: JsonObject | None = None

    def public(self) -> JsonObject:
        object_id = str(self.object_ref["object_id"])
        result: JsonObject = {
            "object_id": object_id,
            "locator": self.locator,
            "type": self.kind,
            "text": self.text,
            "object_ref": self.object_ref,
        }
        if self.style:
            result["style"] = self.style
        if self.format:
            result["format"] = self.format
        return result

@dataclass(frozen=True, slots=True)
class Inspection:
    document_sha256: str
    objects: tuple[InspectedObject, ...]
    summary: JsonObject
    risks: tuple[JsonObject, ...]
    warnings: tuple[JsonObject, ...]
    provider: JsonObject

    def by_id(self) -> dict[str, InspectedObject]:
        return {str(item.object_ref["object_id"]): item for item in self.objects}


def _safe_format(value: Any) -> JsonObject:
    if not isinstance(value, dict):
        return {}
    allowed_prefixes = (
        "effective.",
        "border.",
        "margin",
        "rows",
        "cols",
        "spacing",
        "indent",
        "style",
    )
    result: JsonObject = {}
    for key, item in value.items():
        if not isinstance(key, str) or not isinstance(item, (str, int, float, bool, type(None))):
            continue
        public_key = _FORMAT_ALIASES.get(key, key)
        if public_key in _PUBLIC_FORMAT_KEYS or public_key.startswith(allowed_prefixes):
            result[public_key] = item
    return result


def _package_facts(document: Path) -> JsonObject:
    with zipfile.ZipFile(document) as archive:
        document_root = ET.fromstring(archive.read("word/document.xml"))
        names = archive.namelist()
    return {
        "package_parts": len(names),
        "sections": len(document_root.findall(f".//{{{W_NS}}}sectPr")),
        "images": sum(1 for name in names if name.startswith("word/media/")),
        "drawings": len(document_root.findall(f".//{{{W_NS}}}drawing")),
        "equations": len(
            document_root.findall(
                ".//{http://schemas.openxmlformats.org/officeDocument/2006/math}oMath"
            )
        ),
        "text_boxes": len(document_root.findall(f".//{{{W_NS}}}txbxContent")),
        "vml_objects": len(document_root.findall(f".//{{{V_NS}}}shape")),
        "graphic_objects": len(document_root.findall(f".//{{{A_NS}}}graphic")),
        "footnotes": "word/footnotes.xml" in names,
        "endnotes": "word/endnotes.xml" in names,
        "comments": "word/comments.xml" in names,
        "headers": sum(1 for name in names if re.fullmatch(r"word/header\d+\.xml", name)),
        "footers": sum(1 for name in names if re.fullmatch(r"word/footer\d+\.xml", name)),
        "numbering_part": "word/numbering.xml" in names,
        "styles_part": "word/styles.xml" in names,
        "bookmarks": len(document_root.findall(f".//{{{W_NS}}}bookmarkStart")),
        "fields": len(document_root.findall(f".//{{{W_NS}}}fldSimple"))
        + len(document_root.findall(f".//{{{W_NS}}}fldChar[@{{{W_NS}}}fldCharType='begin']")),
        "content_controls": len(document_root.findall(f".//{{{W_NS}}}sdt")),
        "hyperlinks": len(document_root.findall(f".//{{{W_NS}}}hyperlink")),
        "merged_cells": len(document_root.findall(f".//{{{W_NS}}}gridSpan"))
        + len(document_root.findall(f".//{{{W_NS}}}vMerge")),
        "tracked_insertions": len(document_root.findall(f".//{{{W_NS}}}ins")),
        "tracked_deletions": len(document_root.findall(f".//{{{W_NS}}}del")),
    }


def inspect_document(
    document: Path,
    office: OfficeCliAdapter,
    *,
    selector: str = "paragraph, table, picture",
) -> Inspection:
    from docfit.styles.resolver import EffectiveStyleResolver

    package_warnings = validate_docx_package(document)
    document_sha256 = sha256_file(document)
    raw_objects = office.query(document, selector)
    style_resolver = EffectiveStyleResolver(document)
    objects: list[InspectedObject] = []
    counts: dict[str, int] = {}
    for raw in raw_objects:
        locator = raw.get("path")
        kind = raw.get("type")
        if not isinstance(locator, str) or not isinstance(kind, str):
            continue
        raw_text = raw.get("text")
        text = raw_text if isinstance(raw_text, str) else ""
        raw_style = raw.get("style")
        style = raw_style if isinstance(raw_style, str) else None
        safe_format = _safe_format(raw.get("format"))
        try:
            resolved_style = style_resolver.resolve(locator).as_dict()
        except ToolFailure:
            resolved_style = None
        fingerprint = sha256_json(
            {
                "type": kind,
                "text": text,
                "style": style,
                "format": safe_format,
                "resolved_style": resolved_style,
            }
        )
        identity = {
            "document": document_sha256,
            "locator": locator,
            "type": kind,
        }
        object_id = f"obj-{sha256_json(identity)[:24]}"
        object_ref: JsonObject = {
            "document_sha256": document_sha256,
            "object_id": object_id,
            "expected_fingerprint": fingerprint,
        }
        objects.append(
            InspectedObject(
                locator,
                kind,
                text,
                style,
                safe_format,
                object_ref,
                resolved_style,
            )
        )
        counts[kind] = counts.get(kind, 0) + 1
    facts = _package_facts(document)
    risks: list[JsonObject] = []
    for fact, kind in (
        ("text_boxes", "unsupported_text_box"),
        ("vml_objects", "unsupported_vml_object"),
        ("content_controls", "unsupported_content_control"),
    ):
        count = facts.get(fact)
        if isinstance(count, int) and count:
            risks.append({"kind": kind, "count": count, "blocking": False})
    summary: JsonObject = {
        "paragraphs": counts.get("paragraph", 0),
        "tables": counts.get("table", 0),
        **facts,
    }
    warnings = tuple(
        {
            "code": value,
            "kind": "package",
            "message": "The package contains a non-blocking relationship warning.",
        }
        for value in package_warnings
    )
    return Inspection(
        document_sha256,
        tuple(objects),
        summary,
        tuple(risks),
        warnings,
        office.evidence(),
    )


def inspect_document_snapshot(
    document: Path,
    office: OfficeCliAdapter,
    *,
    selector: str = "paragraph, table, picture",
) -> Inspection:
    """Inspect a private byte-for-byte copy so Office backends cannot dirty inputs."""

    source_hash = sha256_file(document)
    with tempfile.TemporaryDirectory(prefix="docfit-inspect-") as temporary_name:
        snapshot = Path(temporary_name) / document.name
        shutil.copyfile(document, snapshot)
        snapshot.chmod(0o600)
        inspection = inspect_document(snapshot, office, selector=selector)
    if inspection.document_sha256 != source_hash:
        raise ToolFailure(
            status="error",
            origin="postcondition",
            code="inspection_snapshot_hash_mismatch",
            message="The private inspection snapshot was not byte-identical to the source.",
        )
    if sha256_file(document) != source_hash:
        raise ToolFailure(
            status="error",
            origin="postcondition",
            code="inspection_source_changed",
            message="The source document changed while its private snapshot was inspected.",
        )
    return inspection


def resolve_object_ref(reference: Any, inspection: Inspection) -> InspectedObject:
    from docfit.tools.runtime import ToolFailure

    if not isinstance(reference, dict):
        raise ToolFailure(
            status="needs_input",
            origin="request",
            code="invalid_object_ref",
            message="An operation target must be an object_ref object.",
        )
    if reference.get("document_sha256") != inspection.document_sha256:
        raise ToolFailure(
            status="needs_input",
            origin="request",
            code="stale_object_ref",
            message="The object_ref belongs to a different document snapshot; inspect again.",
            suggested_actions=("inspect_document_again",),
        )
    object_id = reference.get("object_id")
    item = inspection.by_id().get(object_id) if isinstance(object_id, str) else None
    if item is None or reference.get("expected_fingerprint") != item.object_ref.get(
        "expected_fingerprint"
    ):
        raise ToolFailure(
            status="needs_input",
            origin="request",
            code="object_fingerprint_mismatch",
            message="The object_ref no longer matches the inspected object; inspect again.",
            suggested_actions=("inspect_document_again",),
        )
    return item
